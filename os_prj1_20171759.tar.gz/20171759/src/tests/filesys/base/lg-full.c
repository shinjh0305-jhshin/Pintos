/* Writes out the contents of a fairly large file all at once,
   and then reads it back to make sure that it was written
   properly. */

#define TEST_SIZE 75678
#include "tests/filesys/base/full.inc"
